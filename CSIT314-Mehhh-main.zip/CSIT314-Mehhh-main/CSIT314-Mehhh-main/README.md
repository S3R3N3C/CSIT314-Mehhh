# CSIT314-Mehhh

To run:

**VSCODE**
1. To setup for php: https://www.youtube.com/watch?v=Qe5Z_TO-X0s

**XAMPP**
1. START Apache, MYSQL
2. MYSQL - Admin to open phpmyadmin
3. Download and Extract the Mehhh.zip - Paste the Mehhh into the C:\xampp\htdocs
4. Updated codes are to be retrieved here [https://github.com/S3R3N3C/CSIT314-Mehhh/Mehhh](https://github.com/S3R3N3C/CSIT314-Mehhh/tree/main/Mehhh)

**phpMyAdmin** 
1. Import the realtyrealm.sql


**AS FOR NOW**
to run and see the website: http://localhost/mehhh
* TAKE NOTE: CSS might not work in CHROME so need to switch browser (EDGE, FIREFOX, etc.)

**--** Mehhh.zip OLD VER **--**
