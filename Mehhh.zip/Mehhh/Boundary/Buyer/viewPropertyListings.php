<?php 

 echo "PROPERTY LISTINGS"

 ?>