<?php
include_once("../../Controller/SystemAdmin/deactivateUserAccountController.php");

if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];

    // Set user status to "Inactive"
    $deactivateUserAccountController = new deactivateUserAccountController();
    $deactivateUserAccountController->deactivateUserAccount($user_id);

    // Redirect to System admin page
    header("Location: ./userAccount.php");
    exit();
}
?>