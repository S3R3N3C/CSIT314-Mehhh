<?php
include_once("../../Controller/SystemAdmin/deactivateUserProfileController.php");

if (isset($_GET['userprofile_id'])) {
    $userprofile_id = $_GET['userprofile_id'];

    // Set user status to "Inactive"
    $deactivateUserProfileController = new deactivateUserProfileController();
    $deactivateUserProfileController->deactivateUserProfile($userprofile_id);

    // Redirect to System admin page
    header("Location: ./userProfile.php");
    exit();
}
?>