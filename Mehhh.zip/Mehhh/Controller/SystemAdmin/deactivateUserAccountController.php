<?php
include_once("../../Entity/UserAccount.php");

class deactivateUserAccountController
{

    public function deactivateUserAccount($user_id)
    {
        $suc = new UserAccount();
        $results = $suc->deactivateUserAccount($user_id);
        return $results;
        
    }
}