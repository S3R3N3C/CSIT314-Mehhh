<?php
include_once("../../Entity/UserProfile.php");

class deactivateUserProfileController
{
 
    public function deactivateUserProfile($userprofile_id)
    {
        $suc = new UserProfile();
        $results = $suc->deactivateUserProfile($userprofile_id);
        return $results;
    }
}